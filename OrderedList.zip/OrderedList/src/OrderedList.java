// Arrays Progamming Assignment
// Programmer : Mirna Farahat


public class OrderedList {
    private int[] a;
    private int numberOfElements;

    public OrderedList(int size) {
        a = new int[size];
        numberOfElements = 0;
    }

    public int search(int item) {
        int low = 0;
        int high = numberOfElements - 1;

        while (true) {
            int mid = (low + high) / 2;
            if (a[mid] == item)
                return mid;
            else if (low > high)
                return -1;
            else {
                if (item > a[mid])
                    low = mid + 1;
                else
                    high = mid - 1;
            }
        }
    }

    public void insert(int item) {
        // insert item into the array a using binary search
        int low = 0;
        int high = numberOfElements - 1;
        int mid = 0;
        while (low <= high) {
            mid = (low + high) / 2;
            if (item > a[mid])
                low = mid + 1;
            else
                high = mid - 1;
        }
        for (int i = numberOfElements; i > low; i--)
            a[i] = a[i - 1];
        a[low] = item;
        numberOfElements++;
    }

    public boolean delete(int item) {
        // find the item
        int i = search(item);

        // didnt find it
        if (i == -1) {
            return false;
        } else {
            for (int j = i; j < numberOfElements; j++) {
                a[j] = a[j + 1];
            }
            numberOfElements--;
            return true;
        }

    }

    public void display() {
        for (int i = 0; i < numberOfElements; i++) {
            System.out.print(a[i] + " ");
        }
    }
    public void merge(OrderedList b) {
        int i = 0;
        int j = 0;
        int k = 0;
        int[] c = new int[numberOfElements + b.numberOfElements];
        while (i < numberOfElements && j < b.numberOfElements) {
            if (a[i] < b.a[j]) {
                c[k] = a[i];
                i++;
            } else {
                c[k] = b.a[j];
                j++;
            }
            k++;
        }
        while (i < numberOfElements) {
            c[k] = a[i];
            i++;
            k++;
        }
        while (j < b.numberOfElements) {
            c[k] = b.a[j];
            j++;
            k++;
        }
        a = c;
        numberOfElements = numberOfElements + b.numberOfElements;
    }
    public static void main(String args[]){
        OrderedList a = new OrderedList(10);
        OrderedList b = new OrderedList(10);
        a.insert(1);
        a.insert(3);
        a.insert(5);
        a.insert(7);
        a.insert(9);
        b.insert(2);
        b.insert(4);
        b.insert(6);
        b.insert(8);
        b.insert(10);
        a.merge(b);
        a.display();
    }
}